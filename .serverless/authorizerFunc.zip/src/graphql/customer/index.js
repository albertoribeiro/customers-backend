module.exports = {
    schema: require('./customerSchema'),
    resolvers: require('./customerResolvers')
}