const enumParams = {
    ARG_TYPE: {
        BODY: 'body',
        QUERYSTRING: 'queryStringParameters',
        PARAMETERS: 'pathParameters',
    }
}

module.exports = enumParams